"""
db_loader.py
------------
Step 2 (backend) + Step 6 (business data layer) support for the chatbot.

Rebuilds a SQLite database from EVERY .csv file found in the data folder.
This is what makes the bot work with "dynamic data": whenever Magento
data changes, just drop new CSVs into the folder and re-run this loader
(or call rebuild_database() from your app) -- no code changes needed,
because table/column names are read from the CSV headers, not hardcoded.

Usage:
    python db_loader.py                # builds ./magento.db from ./data/*.csv
    python db_loader.py --data-dir X --db-path Y.db
"""

import argparse
import csv
import os
import sqlite3
from pathlib import Path


def _infer_sqlite_type(values):
    """Very small type sniffer: INTEGER > REAL > TEXT, based on sample values."""
    is_int = True
    is_real = True
    for v in values:
        if v is None or v == "":
            continue
        try:
            int(v)
        except ValueError:
            is_int = False
        try:
            float(v)
        except ValueError:
            is_real = False
        if not is_int and not is_real:
            break
    if is_int:
        return "INTEGER"
    if is_real:
        return "REAL"
    return "TEXT"


def _table_name_from_csv(csv_path: Path) -> str:
    # catalog_product_entity.csv -> catalog_product_entity
    return csv_path.stem.strip().lower().replace(" ", "_").replace("-", "_")


def load_csv_into_sqlite(conn: sqlite3.Connection, csv_path: Path) -> str:
    table = _table_name_from_csv(csv_path)

    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)

    columns = [h.strip() for h in header]

    # sample up to 200 rows per column to guess a type
    col_types = []
    for i, col in enumerate(columns):
        sample = [r[i] for r in rows[:200] if i < len(r)]
        col_types.append(_infer_sqlite_type(sample))

    conn.execute(f'DROP TABLE IF EXISTS "{table}"')
    col_defs = ", ".join(f'"{c}" {t}' for c, t in zip(columns, col_types))
    conn.execute(f'CREATE TABLE "{table}" ({col_defs})')

    placeholders = ", ".join(["?"] * len(columns))
    insert_sql = f'INSERT INTO "{table}" VALUES ({placeholders})'

    clean_rows = []
    for r in rows:
        # pad short rows, ignore ragged extra columns
        r = (r + [None] * len(columns))[: len(columns)]
        r = [None if v == "" else v for v in r]
        clean_rows.append(r)

    conn.executemany(insert_sql, clean_rows)
    conn.commit()
    return table


_RAW_SUFFIX = "__raw"


def _mask_email(col: str) -> str:
    """SQL expression that keeps only the first letter + domain of an
    email column, e.g. danielle.johnson1@example.com -> d***@example.com."""
    return (
        f'SUBSTR("{col}", 1, 1) || \'***@\' || '
        f'SUBSTR("{col}", INSTR("{col}", \'@\') + 1) AS "{col}"'
    )


# --------------------------------------------------------------------
# SECURITY LAYER: allowlist of columns the CHATBOT is allowed to see,
# per table. Every CSV is loaded into "<table>__raw" first; the bot
# (schema description + SQL guard + LLM) only ever sees/queries the
# public VIEW created from this list -- never the __raw table.
#
#   * value is None            -> expose every column as-is (no PII here)
#   * value is a list of exprs -> expose ONLY these columns/expressions
#   * table absent from here   -> DENIED BY DEFAULT (raw table loaded,
#                                  but no view = chatbot can't see it at
#                                  all). Add new tables here explicitly
#                                  before they become queryable -- this
#                                  is intentional: unknown/new CSVs
#                                  (which might contain PII) never get
#                                  silently exposed.
# --------------------------------------------------------------------
PUBLIC_VIEWS = {
    "customer_entity": [
        "entity_id", "website_id", _mask_email("email"), "group_id",
        "firstname", "lastname", "created_at", "is_active",
    ],
    # telephone + street dropped entirely -- not needed for analytics
    # and too sensitive to hand an LLM that can be prompt-injected.
    "customer_address_entity": [
        "entity_id", "parent_id", "city", "region", "country_id",
    ],
    "catalog_product_entity": None,
    "catalog_category_entity": None,
    # links catalog_category_entity.entity_id <-> catalog_product_entity.entity_id
    # (many-to-many) -- no PII, expose as-is. This is what makes
    # category-based questions ("products in the Women category", "revenue
    # from the Shoes category") answerable instead of a dead end.
    "catalog_category_product": None,
    "sales_order": [
        "entity_id", "increment_id", "customer_id",
        _mask_email("customer_email"), "status", "state", "grand_total",
        "subtotal", "order_currency_code", "created_at",
    ],
    "sales_order_item": None,
    # cc_last4 dropped entirely -- even a masked/partial card number has
    # no business reason to pass through an LLM prompt.
    "sales_order_payment": ["entity_id", "parent_id", "method", "amount_ordered"],
    "sales_invoice": None,
    "sales_shipment": None,
    "quote": [
        "entity_id", "store_id", "customer_id", _mask_email("customer_email"),
        "is_active", "items_count", "grand_total", "created_at",
    ],
}


def _create_public_views(conn: sqlite3.Connection) -> None:
    """Renames every loaded table to "<name>__raw" and, for tables listed
    in PUBLIC_VIEWS, creates a same-named VIEW exposing only the allowed
    columns. SQLite views are read-only by default, so this also removes
    any accidental write path. Tables NOT in PUBLIC_VIEWS get no view at
    all -- they still exist for admin/debug use but are invisible to the
    chatbot (schema_utils and sql_guard only ever look at type='view')."""
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    raw_tables = [r[0] for r in cur.fetchall()]

    for table in raw_tables:
        raw_name = f"{table}{_RAW_SUFFIX}"
        cur.execute(f'ALTER TABLE "{table}" RENAME TO "{raw_name}"')

        if table not in PUBLIC_VIEWS:
            continue  # denied by default -- no public view created

        cols = PUBLIC_VIEWS[table]
        if cols is None:
            cur.execute(f'PRAGMA table_info("{raw_name}")')
            select_list = ", ".join(f'"{r[1]}"' for r in cur.fetchall())
        else:
            select_list = ", ".join(cols)

        cur.execute(f'CREATE VIEW "{table}" AS SELECT {select_list} FROM "{raw_name}"')

    # A safe window onto sqlite_master for schema/"what tables exist"
    # questions -- excludes the __raw tables so the LLM never learns
    # they exist, even by name.
    cur.execute(
        "CREATE VIEW schema_catalog AS "
        "SELECT type, name, tbl_name FROM sqlite_master "
        f"WHERE type='view' AND name NOT LIKE '%{_RAW_SUFFIX}' "
        "AND name != 'schema_catalog'"
    )
    conn.commit()


def rebuild_database(data_dir: str = "data", db_path: str = "magento.db") -> list:
    """Wipes and rebuilds db_path from every CSV in data_dir. Returns the
    names of the PUBLIC views the chatbot is allowed to query (not the
    raw table names)."""
    data_dir_path = Path(data_dir)
    csv_files = sorted(data_dir_path.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No CSV files found in {data_dir_path.resolve()}")

    # fresh DB each time so stale/removed tables don't linger
    if os.path.exists(db_path):
        os.remove(db_path)

    conn = sqlite3.connect(db_path)
    for csv_path in csv_files:
        load_csv_into_sqlite(conn, csv_path)

    _create_public_views(conn)

    cur = conn.cursor()
    cur.execute(
        "SELECT name FROM sqlite_master WHERE type='view' AND name != 'schema_catalog'"
    )
    public_views = [r[0] for r in cur.fetchall()]
    conn.close()
    return public_views


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build/refresh the chatbot's SQLite DB from CSVs")
    parser.add_argument("--data-dir", default="data")
    parser.add_argument("--db-path", default="magento.db")
    args = parser.parse_args()

    tables = rebuild_database(args.data_dir, args.db_path)
    print(f"Built {args.db_path} with {len(tables)} tables:")
    for t in tables:
        print(f"  - {t}")
