"""
schema_utils.py
----------------
Reads the CURRENT schema straight from SQLite (not a hardcoded doc), so
if you add/remove/rename CSV files and rebuild the DB, the chatbot's
understanding of "what tables/columns exist" updates automatically.
"""

import sqlite3


def get_schema_description(db_path: str = "magento.db") -> str:
    """Returns a compact text description of every table + its columns,
    suitable to paste into an LLM prompt."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # SECURITY: only ever look at type='view'. db_loader.py renames every
    # raw CSV-loaded table to "<name>__raw" and exposes just an allowlisted
    # subset of columns through a same-named VIEW (see PUBLIC_VIEWS in
    # db_loader.py). Querying sqlite_master for type='table' here would
    # leak the existence -- and column names -- of the raw PII tables to
    # the LLM, which is exactly what this guard exists to prevent.
    cur.execute(
        "SELECT name FROM sqlite_master WHERE type='view' AND name != 'schema_catalog'"
    )
    tables = [r[0] for r in cur.fetchall()]

    lines = []
    for table in tables:
        cur.execute(f'PRAGMA table_info("{table}")')
        cols = cur.fetchall()  # cid, name, type, notnull, dflt, pk
        col_desc = ", ".join(f"{c[1]} ({c[2]})" for c in cols)

        cur.execute(f'SELECT COUNT(*) FROM "{table}"')
        row_count = cur.fetchone()[0]

        lines.append(f"- {table} [{row_count} rows]: {col_desc}")

    conn.close()
    return "\n".join(lines)


def get_sample_rows(table: str, db_path: str = "magento.db", limit: int = 3) -> str:
    """A few sample rows from a table, useful extra context for the LLM."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(f'SELECT * FROM "{table}" LIMIT {int(limit)}')
    cols = [d[0] for d in cur.description]
    rows = cur.fetchall()
    conn.close()
    out = [", ".join(cols)]
    for r in rows:
        out.append(", ".join(str(v) for v in r))
    return "\n".join(out)


if __name__ == "__main__":
    print(get_schema_description())
