"""
pipeline.py
-----------
The full pipeline, step-numbered to match your diagram:

  Step 1: user message            (function argument)
  Step 2: message reaches backend (this function is the backend)
  Step 3: Backend calls LLM API   -> nl_to_sql()
  Step 4: LLM API returns result  -> the generated SQL
  Step 5: decision -- is a real "action" (data lookup) needed?
  Step 6: Backend calls business API -> run_safe_query() against SQLite
  Step 7: Backend sends final reply  -> rows_to_reply()

Used by both app.py (web server) and cli.py (terminal chat).
"""

import re
import sqlite3

from llm_client import nl_to_sql
from reply_formatter import rows_to_reply
from schema_utils import get_schema_description
from sql_guard import UnsafeQueryError, run_safe_query

DB_PATH = "magento.db"

# How many times we let the model try again after its own SQL fails to
# execute (e.g. it referenced a column/table that doesn't actually exist).
# This is what makes phrasing differences ("give me info about entity id 7"
# vs "entity id 7") self-correct instead of surfacing as a raw crash.
_MAX_SQL_ATTEMPTS = 3


def _friendly_table_list(schema: str) -> str:
    """Turns the raw schema description into a short, human sentence
    listing what's actually queryable -- used so "I couldn't answer that"
    tells the user something useful instead of leaving them to guess."""
    names = re.findall(r"^-\s+([A-Za-z0-9_]+)\s+\[", schema, re.MULTILINE)
    if not names:
        return ""
    pretty = [n.replace("_entity", "").replace("_", " ").strip() for n in names]
    return "Right now I can answer questions about: " + ", ".join(pretty) + "."


def answer_question(question: str, db_path: str = DB_PATH, history: list = None) -> dict:
    """Runs the full pipeline for one user question. Never raises --
    always returns a dict with a user-facing "reply", even on failure.

    `history` is an optional list of (role, content) tuples for the recent
    conversation, so short follow-up replies (e.g. "a customer", "all",
    "yes") can be resolved against what was actually being discussed --
    without this, each message is answered with zero memory of the last.
    """

    try:
        schema = get_schema_description(db_path)
    except sqlite3.Error as e:
        return {
            "question": question,
            "sql": None,
            "reply": f"I couldn't read the database schema right now ({e}). Please try again.",
        }

    sql = None
    last_error = None

    for attempt in range(1, _MAX_SQL_ATTEMPTS + 1):
        try:
            sql = nl_to_sql(question, schema, prior_error=last_error, history=history)
        except RuntimeError as e:
            return {
                "question": question,
                "sql": None,
                "reply": f"I couldn't reach the language model to answer that ({e}). Please try again.",
            }

        if sql.strip().upper() == "NO_QUERY_POSSIBLE":
            hint = _friendly_table_list(schema)
            return {
                "question": question,
                "sql": None,
                "reply": (
                    "I couldn't find data connecting that to anything in this "
                    "dataset -- it likely needs a field this data doesn't have "
                    "(like a customer's age, loyalty status, or a per-customer "
                    "demographic attribute). "
                    + hint
                ).strip(),
            }

        if sql.strip().upper().startswith("CLARIFY:"):
            clarification = sql.split(":", 1)[1].strip()
            return {
                "question": question,
                "sql": None,
                "reply": clarification or "Could you clarify which record you mean?",
            }

        try:
            columns, rows = run_safe_query(sql, db_path)
        except UnsafeQueryError as e:
            return {
                "question": question,
                "sql": sql,
                "reply": f"I generated a query I'm not allowed to run safely ({e}). Please rephrase your question.",
            }
        except sqlite3.Error as e:
            # The SQL was "safe" (passed the guard) but SQLite rejected it,
            # e.g. "no such column: xyz". Give the model one chance to see
            # its own error and correct itself before giving up.
            last_error = f"{type(e).__name__}: {e}\nFailed SQL:\n{sql}"
            if attempt < _MAX_SQL_ATTEMPTS:
                continue
            return {
                "question": question,
                "sql": sql,
                "reply": (
                    "I ran into a database error while answering that. "
                    "Could you rephrase the question or be more specific "
                    "(e.g. which table or record you mean)?"
                ),
            }
        else:
            break

    try:
        reply = rows_to_reply(question, sql, columns, rows)
    except RuntimeError as e:
        # Query worked, just couldn't get a nicely-worded summary -- fall
        # back to showing the raw results rather than an error bubble.
        reply = f"Here are the results ({e} while summarizing):\n\n" + str(
            {"columns": columns, "rows": rows[:20]}
        )

    return {"question": question, "sql": sql, "columns": columns, "rows": rows, "reply": reply}
