"""
llm_client.py
-------------
Wraps the ONE LLM call left in the pipeline -- using the Groq API
(OpenAI-compatible, very fast, generous free tier).

  nl_to_sql()  -> understands the user's question, writes SQL against
                  the live (masked, allowlisted) schema.

By design, this is the ONLY place in the whole app that talks to Groq,
and it only ever sends the user's question text + conversation history +
the table/column schema (structure, never actual row data). Turning the
SQL results back into a reply happens locally in reply_formatter.py, with
plain Python -- no network call -- so no query result (not even the
already-masked ones) is ever sent to Groq or anywhere else.

The API key is read from a `.env` file (GROQ_API_KEY=...) in this folder,
or from the GROQ_API_KEY environment variable if you already set that some
other way.

Get a free key at https://console.groq.com/keys

    pip install groq python-dotenv
"""

import os
import re
from datetime import date

from dotenv import load_dotenv
from groq import Groq

load_dotenv()  # reads a .env file in the current folder, if present

# Solid general-purpose model for SQL generation on Groq. Groq deprecated
# the llama-3.x chat models -- openai/gpt-oss-120b is the current
# recommended general-purpose/reasoning model. For a faster/cheaper
# (slightly less accurate) option, try "openai/gpt-oss-20b".
MODEL = "openai/gpt-oss-120b"

_SQL_SYSTEM_PROMPT = """You are the query-planning layer of a data chatbot for a Magento \
e-commerce store. You are given the LIVE database schema (tables, columns, types, row \
counts) and a user's natural-language question.

Your ONLY job: output a single safe, read-only SQLite SELECT statement that answers the \
question, using ONLY the tables/columns listed in the schema. Never invent a table or \
column that isn't listed.

IMPORTANT: the LIVE SCHEMA below already IS the full set of tables/columns you're allowed \
to touch -- it's a curated, PII-safe view layer, not the raw database. Some columns (like \
email addresses) are already partially masked at the database level; that's expected and \
not something you need to work around. If something a user asks for genuinely isn't in the \
schema (e.g. a column, or a relationship between two tables, that doesn't exist), that's a \
real limitation of the dataset -- output NO_QUERY_POSSIBLE rather than guessing at a table \
or join that isn't listed.

Rules:
- Output ONLY the SQL. No explanation, no markdown fences, no commentary.
- Only SELECT / WITH statements. Never write/alter data or schema.
- If the question can't be answered from the given schema, output exactly:
  NO_QUERY_POSSIBLE
- COUNTS, SUMS, AVERAGES: for "how many", "total", "average" questions, use COUNT/SUM/AVG
  directly -- don't return raw rows for the caller to count themselves. E.g. "how many
  orders are pending" -> SELECT COUNT(*) FROM sales_order WHERE LOWER(status)='pending'.
- TOP-N / RANKING: for "best-selling", "top N", "most/least", "highest/lowest" questions,
  use ORDER BY ... LIMIT N. Default to LIMIT 10 if the user didn't give a number.
  E.g. "top 5 most expensive products" ->
  SELECT name, price FROM catalog_product_entity ORDER BY price DESC LIMIT 5
- REVENUE / SALES BY PRODUCT: sales_order_item has qty_ordered and row_total per line item --
  use SUM(row_total) grouped by product/sku for "best-selling" or "revenue by product"
  questions, e.g.:
  SELECT sku, name, SUM(qty_ordered) AS units, SUM(row_total) AS revenue
  FROM sales_order_item GROUP BY sku, name ORDER BY revenue DESC LIMIT 10
- CUSTOMER SPEND / ORDER COUNT: join sales_order to customer_entity on customer_id =
  entity_id for "top customers by spend" style questions, e.g.:
  SELECT c.firstname, c.lastname, SUM(o.grand_total) AS total_spent
  FROM sales_order o JOIN customer_entity c ON o.customer_id = c.entity_id
  GROUP BY c.entity_id ORDER BY total_spent DESC LIMIT 10
- RELATIVE DATES: you're given TODAY'S DATE below. Translate phrases like "last month",
  "this year", "in the past 30 days", "last week" into SQLite date comparisons against the
  relevant *_created_at column, e.g. "orders from the last 30 days" ->
  WHERE created_at >= date('now', '-30 days')  (use the given today's date, not a guess).
  "this year" -> WHERE strftime('%Y', created_at) = strftime('%Y', 'now')
- STATUS / METHOD / CITY / REGION FILTERS: sales_order.status, sales_order_payment.method,
  customer_address_entity.city/region are real filterable values -- match them the same way
  as category names above (exact, case-insensitive, never substring LIKE for short enum-like
  words).
- CATEGORY-BASED QUESTIONS: catalog_category_product is a link table with columns
  category_id (-> catalog_category_entity.entity_id) and product_id (->
  catalog_product_entity.entity_id). Use it for ANY question about products "in"/"under" a
  named category, or sales/revenue/units tied to a category, e.g.:
  "how many products are in the Shoes category?" ->
  SELECT COUNT(*) FROM catalog_category_product cp
  JOIN catalog_category_entity cc ON cp.category_id = cc.entity_id
  WHERE LOWER(cc.name) = LOWER('Shoes')
  "revenue from the Women category last month" ->
  SELECT SUM(oi.row_total) FROM sales_order_item oi
  JOIN catalog_category_product cp ON oi.product_id = cp.product_id
  JOIN catalog_category_entity cc ON cp.category_id = cc.entity_id
  JOIN sales_order o ON oi.order_id = o.entity_id
  WHERE LOWER(cc.name) = LOWER('Women') AND o.created_at >= date('now', 'start of month', '-1 month')
    AND o.created_at < date('now', 'start of month')
  A category name can repeat across multiple entity_ids (different category rows can share a
  name) -- always match by LOWER(name) = LOWER('...'), never by assuming a single id, so every
  matching category is included.
- CATEGORY NAME vs CUSTOMER DEMOGRAPHIC -- IMPORTANT DISAMBIGUATION: some category names
  (e.g. "Men", "Women", "Kids") are also words for a customer demographic/gender. This schema
  has NO customer gender/age/demographic field anywhere -- customer_entity only has
  entity_id, website_id, email (masked), group_id, firstname, lastname, created_at, is_active.
  When a question uses one of these words, always resolve it as the PRODUCT CATEGORY (via
  catalog_category_product as above), never as a customer attribute -- that's the only
  grounded reading this data supports. E.g. "how many products did women buy last month" ->
  treat as "how many products in the Women category were bought last month" (join
  sales_order_item -> catalog_category_product -> catalog_category_entity, filter category
  name = 'Women', filter by date, SUM or COUNT as appropriate) -- do NOT return
  NO_QUERY_POSSIBLE just because the phrasing sounds demographic, as long as the word matches
  a real category name. Only fall back to NO_QUERY_POSSIBLE for demographic questions that
  name something with NO matching category at all (e.g. "customers over 40", "male
  customers' emails", "which customers identify as female" -- these ask for a per-customer
  attribute directly, not a product/category count, so there's no category-based reading to
  fall back on).
- Prefer explicit column lists over SELECT *.
- Add a LIMIT if the user didn't ask for an aggregate/summary and the result could be large.
- For questions ABOUT the schema itself (how many tables exist, what tables/columns are
  there, does table X exist, etc.), query `schema_catalog`
  (columns: type, name, tbl_name) -- this is the only schema catalog you may query; it
  already contains exactly the tables you're allowed to see, nothing else, e.g.
  SELECT COUNT(*) FROM schema_catalog
  SELECT name FROM schema_catalog
  Never query the real `sqlite_master` table directly -- it isn't accessible to you.
  Do NOT return NO_QUERY_POSSIBLE for schema/structure questions -- schema_catalog answers them.
- Be generous with short or vague questions. If a word in the question plausibly matches a
  real value that would appear in a column (a category name, status, city, etc.), write a
  query that filters/counts on that value, rather than giving up.
  For short, word-like values (category names, statuses, cities, product types) prefer an
  EXACT case-insensitive match: WHERE LOWER(name) = LOWER('men'). Do NOT use a substring
  LIKE '%men%' for these, since it can wrongly match unrelated values that merely contain
  the same letters (e.g. '%men%' also matches 'Women' -- a real bug to avoid).
  Only use LIKE '%...%' for genuine free-text search fields (e.g. matching part of a longer
  product name or description), never for short category/status/enum-like words.
- Only return NO_QUERY_POSSIBLE when the question's subject has no plausible match anywhere
  in the schema at all (e.g. asking about something with no related table or column, like
  weather or a topic never mentioned in the schema) -- not just because the phrasing is short.
- Treat different phrasings of the same request identically: "give me information about
  entity id 7", "entity id 7", "show entity 7", "info on record 7", "look up id 7" etc. are
  ALL the same request. Do not let extra polite/filler words ("give me", "please", "can you",
  "information about", "tell me", "I want to know") change which table or columns you pick --
  strip them mentally and focus only on the concrete nouns/values that remain.
- AMBIGUOUS ENTITY REFERENCES: several tables share the identical primary-key column name
  `entity_id` (e.g. customer_entity, catalog_product_entity, catalog_category_entity,
  sales_order, sales_invoice, sales_shipment, quote, sales_order_payment, customer_address_entity).
  If the user gives a bare "entity id N" / "id N" / "record N" with NO other word in the
  question that hints which of these tables they mean (no "customer", "order", "product",
  "invoice", "shipment", "category", "address", "quote", "cart", etc.), do NOT silently guess
  one table. Instead output exactly:
  CLARIFY: <short natural question listing the plausible tables, e.g. "Which record did you
  mean by entity id 7 -- a customer, a product, a category, an order, an invoice, a shipment,
  a quote, or a payment?">
  If the question DOES contain a word that identifies the entity type ("customer 7",
  "order id 7", "product entity 7"), do NOT ask for clarification -- just query that table
  directly, no matter how the rest of the sentence is phrased.
- FOLLOW-UP / CLARIFICATION REPLIES: you may be given CONVERSATION HISTORY above the current
  question. If the current message is short and only makes sense as an answer to your own
  prior CLARIFY question (e.g. "a customer", "the order one", "product", "yes", "all", "1"),
  resolve it using that history instead of treating it as a brand-new standalone question.
  Combine the earlier specifics (like the id value) with this answer to build the real query.
  - If the reply names ONE type ("a customer"), write a normal SELECT ... WHERE entity_id = N
    against that one table.
  - If the reply means ALL plausible types ("all", "all of them", "every table", "check all"),
    write a SINGLE query that checks entity_id = N in every candidate table and combines the
    results with UNION ALL, adding a literal text column so the source table is identifiable,
    e.g.:
    SELECT 'customer' AS source, entity_id, email AS detail FROM customer_entity WHERE entity_id = 7
    UNION ALL
    SELECT 'product' AS source, entity_id, name AS detail FROM catalog_product_entity WHERE entity_id = 7
    UNION ALL ... (one branch per candidate table, using a representative column or two as
    "detail" -- this is still a single read-only SELECT so it's allowed.)
  - If the reply is genuinely unusable even with history (e.g. it doesn't answer the
    clarification at all), output CLARIFY again, rephrasing to make the options clearer.

Examples (illustrating phrasing-invariance and the ambiguity rule):
Q: "give me information about customer 7"
A: SELECT * FROM customer_entity WHERE entity_id = 7
Q: "customer 7"
A: SELECT * FROM customer_entity WHERE entity_id = 7
Q: "tell me about order id 105"
A: SELECT * FROM sales_order WHERE entity_id = 105
Q: "entity id 7"
A: CLARIFY: Which record did you mean by entity id 7 -- a customer, a product, a category, an order, an invoice, a shipment, a quote, or a payment?
Q: "give me information about entity id 7"
A: CLARIFY: Which record did you mean by entity id 7 -- a customer, a product, a category, an order, an invoice, a shipment, a quote, or a payment?

Example follow-up resolution (using conversation history):
History:
  user: entity id 7
  assistant: CLARIFY: Which record did you mean by entity id 7 -- a customer, a product, a category, an order, an invoice, a shipment, a quote, or a payment?
Current question: "a customer"
A: SELECT * FROM customer_entity WHERE entity_id = 7

History:
  user: can you give me all data about entity id 7
  assistant: CLARIFY: Which record did you mean by entity id 7 -- a customer, a product, a category, an order, an invoice, a shipment, a quote, or a payment?
Current question: "all"
A: SELECT 'customer' AS source, entity_id, email AS detail FROM customer_entity WHERE entity_id = 7
UNION ALL
SELECT 'product' AS source, entity_id, name AS detail FROM catalog_product_entity WHERE entity_id = 7
UNION ALL
SELECT 'category' AS source, entity_id, name AS detail FROM catalog_category_entity WHERE entity_id = 7
UNION ALL
SELECT 'order' AS source, entity_id, increment_id AS detail FROM sales_order WHERE entity_id = 7
UNION ALL
SELECT 'invoice' AS source, entity_id, increment_id AS detail FROM sales_invoice WHERE entity_id = 7
UNION ALL
SELECT 'shipment' AS source, entity_id, increment_id AS detail FROM sales_shipment WHERE entity_id = 7
UNION ALL
SELECT 'quote' AS source, entity_id, customer_email AS detail FROM quote WHERE entity_id = 7
UNION ALL
SELECT 'payment' AS source, entity_id, method AS detail FROM sales_order_payment WHERE entity_id = 7
"""


def _client() -> Groq:
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GROQ_API_KEY not found. Create a .env file next to app.py with a line:\n"
            "GROQ_API_KEY=your-key-here\n"
            "(get a free key at https://console.groq.com/keys)"
        )
    return Groq(api_key=api_key)


def nl_to_sql(
    question: str,
    schema_description: str,
    prior_error: str = None,
    history: list = None,
) -> str:
    """Step 3 of the pipeline: understand the question, write SQL for it.

    `history` is an optional list of (role, content) tuples for the recent
    conversation (most recent last). It lets short follow-up replies like
    "a customer" or "all" be resolved against the original question instead
    of being answered with zero context.

    If `prior_error` is given, this is a retry: we tell the model the SQL it
    wrote last time failed (and why), so it can self-correct instead of the
    caller just showing the user a raw error.
    """
    client = _client()

    today = date.today().isoformat()
    prompt_parts = [f"TODAY'S DATE: {today}", f"LIVE SCHEMA:\n{schema_description}"]

    if history:
        history_lines = [f"{role}: {content}" for role, content in history]
        prompt_parts.append(
            "CONVERSATION HISTORY (most recent last):\n" + "\n".join(history_lines)
        )

    prompt_parts.append(f"CURRENT USER QUESTION:\n{question}")
    prompt = "\n\n".join(prompt_parts)

    if prior_error:
        prompt += (
            f"\n\nYour previous SQL for this question failed to run against "
            f"this exact schema with this error:\n{prior_error}\n"
            f"Write a corrected query using ONLY tables/columns from the schema above."
        )

    try:
        resp = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": _SQL_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            max_tokens=400,
            temperature=0,
            reasoning_effort="low",  # this task doesn't need deep reasoning; keeps latency/leakage down
        )
    except Exception as e:
        # Network errors, rate limits, invalid key, etc. -- never let these
        # escape as an unhandled exception all the way to the frontend.
        raise RuntimeError(f"LLM request failed while generating SQL: {e}") from e

    text = (resp.choices[0].message.content or "").strip()
    if not text:
        raise RuntimeError("The model returned an empty response while generating SQL.")

    text = re.sub(r"^```(sql)?", "", text, flags=re.IGNORECASE).strip()
    text = re.sub(r"```$", "", text).strip()

    # Safety net: gpt-oss (reasoning) models occasionally leak chain-of-thought
    # or control tokens (e.g. "<|...|>") into `content` instead of keeping it
    # in the separate `reasoning` field. If the cleaned text doesn't already
    # start with a valid answer, pull out the first line that does.
    if not re.match(r"^\s*(SELECT|WITH|NO_QUERY_POSSIBLE|CLARIFY:)", text, re.IGNORECASE):
        match = re.search(
            r"(?:^|\n)\s*(SELECT\b.*|WITH\b.*|NO_QUERY_POSSIBLE\s*$|CLARIFY:.*)",
            text,
            re.IGNORECASE | re.DOTALL,
        )
        if match:
            text = match.group(1).strip()

    return text


# NOTE: rows_to_reply() used to live here and sent the actual query
# results to Groq so it could phrase a friendly sentence. That's been
# moved to reply_formatter.py, which formats results locally with plain
# Python -- no network call, so query results (even the already-masked
# ones) never leave this server. Only nl_to_sql() above still talks to
# Groq, and it only ever sends the user's question text plus the
# table/column schema -- never any actual row data.
