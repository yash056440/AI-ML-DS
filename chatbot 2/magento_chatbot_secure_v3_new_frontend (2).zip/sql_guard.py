"""
sql_guard.py
------------
Security layer sitting between the LLM's generated SQL and the real
database. Mirrors the diagram's principle: the END USER never talks to
the database directly -- only the backend does, and even the backend
only runs SQL that passes these checks.

Rules enforced:
  1. Must be a single statement.
  2. Must start with SELECT (read-only -- no INSERT/UPDATE/DELETE/DROP/
     ALTER/ATTACH/PRAGMA-write etc).
  3. No semicolon-stacked second statement (blocks SQL injection style
     "; DROP TABLE ...").
  4. Blocklist of dangerous keywords even inside subqueries/CTEs.
  5. Auto-adds a LIMIT if the query doesn't have one, to avoid huge dumps.
  6. Runs against a connection opened in READ-ONLY mode at the OS/sqlite
     level (belt-and-braces on top of the keyword checks).
"""

import re
import sqlite3
from pathlib import Path

_FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|REPLACE|ATTACH|DETACH|"
    r"VACUUM|PRAGMA|TRIGGER|TRANSACTION|COMMIT|ROLLBACK)\b",
    re.IGNORECASE,
)

# Defense-in-depth: even though schema_utils never *tells* the LLM these
# things exist, a prompt-injected or hallucinated query could still try
# to reference them directly. Block it at execution time too, so the
# security boundary doesn't depend on the LLM behaving.
_RAW_TABLE_REF = re.compile(r"__raw\b", re.IGNORECASE)
_BARE_SQLITE_MASTER = re.compile(r"\bsqlite_master\b", re.IGNORECASE)

_DEFAULT_LIMIT = 200


class UnsafeQueryError(Exception):
    pass


def _get_allowed_tables(db_path: str) -> set:
    """The live allowlist: only real VIEWs (public, non-PII) plus the
    safe schema_catalog window. Raw "<name>__raw" tables are never
    in this set, no matter what the query text asks for."""
    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='view'")
        return {r[0] for r in cur.fetchall()}
    finally:
        conn.close()


def validate_sql(sql: str, db_path: str = "magento.db") -> str:
    """Raises UnsafeQueryError if sql isn't a safe, single, read-only
    SELECT against an allowlisted view. Returns a cleaned/limited version
    of the query otherwise."""
    cleaned = sql.strip().rstrip(";").strip()

    if not cleaned:
        raise UnsafeQueryError("Empty query.")

    if ";" in cleaned:
        raise UnsafeQueryError("Multiple statements are not allowed.")

    if not re.match(r"^\s*(SELECT|WITH)\b", cleaned, re.IGNORECASE):
        raise UnsafeQueryError("Only SELECT (read-only) queries are allowed.")

    if _FORBIDDEN.search(cleaned):
        raise UnsafeQueryError("Query contains a forbidden write/schema keyword.")

    if _RAW_TABLE_REF.search(cleaned):
        raise UnsafeQueryError("Query references an internal table that isn't exposed to the chatbot.")

    if _BARE_SQLITE_MASTER.search(cleaned):
        raise UnsafeQueryError("sqlite_master isn't accessible; use schema_catalog for schema questions.")

    # Table/view allowlist: every identifier following FROM or JOIN must
    # be a real, public VIEW (or schema_catalog). This is what
    # actually stops a full-table PII dump -- not just trusting that the
    # LLM only ever saw safe table names in its prompt.
    referenced = re.findall(r"\b(?:FROM|JOIN)\s+\"?([A-Za-z_][A-Za-z0-9_]*)\"?", cleaned, re.IGNORECASE)
    allowed = _get_allowed_tables(db_path) | {"schema_catalog"}
    for name in referenced:
        if name.lower() not in {a.lower() for a in allowed}:
            raise UnsafeQueryError(
                f'"{name}" isn\'t a table this chatbot is allowed to read. '
                "Only the public, non-sensitive views are exposed."
            )

    if not re.search(r"\bLIMIT\b", cleaned, re.IGNORECASE):
        cleaned = f"{cleaned}\nLIMIT {_DEFAULT_LIMIT}"

    return cleaned


def run_safe_query(sql: str, db_path: str = "magento.db"):
    """Validates then executes a query against a read-only connection.
    Returns (columns, rows)."""
    safe_sql = validate_sql(sql, db_path)

    db_uri = f"file:{Path(db_path).resolve()}?mode=ro"
    conn = sqlite3.connect(db_uri, uri=True)
    try:
        cur = conn.cursor()
        cur.execute(safe_sql)
        cols = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchall()
        return cols, rows
    finally:
        conn.close()


if __name__ == "__main__":
    # quick self-test
    ok = "SELECT name, price FROM catalog_product_entity ORDER BY price DESC"
    print("cleaned:", validate_sql(ok))

    for bad in [
        "DROP TABLE customer_entity",
        "SELECT * FROM sales_order; DELETE FROM sales_order",
        "UPDATE customer_entity SET email='x'",
    ]:
        try:
            validate_sql(bad)
            print("FAILED TO BLOCK:", bad)
        except UnsafeQueryError as e:
            print("blocked OK ->", bad, "|", e)
