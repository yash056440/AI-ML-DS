"""
reply_formatter.py
-------------------
Turns raw SQL results into a human-readable reply WITHOUT calling any LLM.

This replaces the old llm_client.rows_to_reply(), which sent the actual
query result rows to Groq so it could phrase a nice sentence. That meant
Groq received real (if already-masked) customer/order data on every
question. This module does the same formatting job with plain Python
string logic instead, so query results never leave this server at all --
only the ORIGINAL nl_to_sql() call still talks to Groq, and it only ever
sends the user's question text plus the table/column schema (structure,
not data).
"""

def _fmt_value(col: str, value) -> str:
    if value is None:
        return "-"
    # Only floats get currency-style formatting -- integers (counts, ids,
    # quantities) print as-is even if the column name happens to contain
    # a word like "total" (e.g. COUNT(*) AS total should read "20", not
    # "20.00").
    if isinstance(value, float):
        return f"{value:,.2f}"
    return str(value)


def _pretty_col(col: str) -> str:
    return col.replace("_", " ").strip()


def rows_to_reply(question: str, sql: str, columns: list, rows: list) -> str:
    """Formats (columns, rows) into a plain-text/markdown reply. Pure
    Python -- no network calls, no data ever sent anywhere."""
    if not rows:
        return "No matching results were found for that -- try rephrasing or asking about a different table."

    total = len(rows)

    # Single value (e.g. a COUNT(*) or SUM(...)): answer in one line.
    if total == 1 and len(columns) == 1:
        return f"{_pretty_col(columns[0])}: {_fmt_value(columns[0], rows[0][0])}"

    # One row, several columns: a clean key/value list (a single record lookup).
    if total == 1:
        lines = [f"- **{_pretty_col(c)}**: {_fmt_value(c, v)}" for c, v in zip(columns, rows[0])]
        return "\n".join(lines)

    # Multiple rows: a markdown table, capped for readability.
    display_rows = rows[:50]
    header = "| " + " | ".join(_pretty_col(c) for c in columns) + " |"
    divider = "|" + "|".join(["---"] * len(columns)) + "|"
    body = [
        "| " + " | ".join(_fmt_value(c, v) for c, v in zip(columns, r)) + " |"
        for r in display_rows
    ]
    table = "\n".join([header, divider, *body])

    note = f"Found {total} result(s)"
    if total > len(display_rows):
        note += f" (showing the first {len(display_rows)})"
    note += ":"

    return f"{note}\n\n{table}"
