"""
app.py
------
The website version of the chatbot. Serves:
  - GET  /              the chat frontend (static/index.html)
  - GET  /api/tables     the live list of tables (for the sidebar)
  - POST /api/chat       {"question": "..."} -> runs the full pipeline

Run:
    pip install -r requirements.txt
    (create a .env file with GEMINI_API_KEY=your-key-here)
    python app.py

Then open http://localhost:8000 in your browser.
"""

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from db_loader import rebuild_database
from pipeline import DB_PATH, answer_question
from schema_utils import get_schema_description


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Step 2 groundwork: (re)build the SQLite DB from whatever CSVs are in
    # ./data right now, so the bot always reflects the current data.
    rebuild_database("data", DB_PATH)
    yield


app = FastAPI(title="Magento Data Chatbot", lifespan=lifespan)

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class HistoryTurn(BaseModel):
    role: str  # "user" or "assistant"
    content: str


class ChatRequest(BaseModel):
    question: str
    history: list[HistoryTurn] = []


@app.get("/")
def index():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/tables")
def list_tables():
    """Returns table names + row counts for the sidebar, read live from SQLite."""
    import sqlite3

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    # SECURITY: only the public VIEWs (never the raw "<name>__raw" tables)
    # so the sidebar itself can't be used to enumerate PII tables.
    cur.execute(
        "SELECT name FROM sqlite_master "
        "WHERE type='view' AND name != 'schema_catalog' "
        "ORDER BY name"
    )
    names = [r[0] for r in cur.fetchall()]
    tables = []
    for name in names:
        cur.execute(f'SELECT COUNT(*) FROM "{name}"')
        count = cur.fetchone()[0]
        tables.append({"name": name, "rows": count})
    conn.close()
    return {"tables": tables}


@app.post("/api/chat")
def chat(req: ChatRequest):
    question = req.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="Question can't be empty.")

    try:
        history = [(t.role, t.content) for t in req.history]
        result = answer_question(question, history=history)
    except Exception as e:
        # answer_question() is written to always return a dict rather than
        # raise, but this is a safety net: any unexpected error (missing
        # GEMINI_API_KEY, network issue, etc.) still comes back as JSON with
        # a real "detail" message instead of a bare 500 that the frontend
        # can only render as "Something went wrong."
        raise HTTPException(status_code=500, detail=f"{type(e).__name__}: {e}")

    return {
        "reply": result["reply"],
        "sql": result.get("sql"),
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)
