# Magento Data Chatbot — Website Version

A local website where you (or your team) can ask plain-English questions
about your Magento data — tables, rows, columns, totals — and get a
human-sounding answer back. Runs entirely on your own machine.

## How it works (matches the diagram you shared)

| Diagram step | This project |
|---|---|
| 1. User types a message | Typed into the chat box in the browser |
| 2. Message reaches backend | `POST /api/chat` in `app.py` |
| 3. Backend calls LLM API | `llm_client.nl_to_sql()` — Gemini reads the **live** schema and writes SQL |
| 4. LLM API returns result | The generated SQL |
| 5. Decision | `sql_guard.py` checks the query is safe (read-only) |
| 6. Backend calls business API | `sql_guard.run_safe_query()` — runs against a **read-only** SQLite connection |
| 7. Backend sends final reply | `llm_client.rows_to_reply()` — Gemini turns the raw rows into a natural answer, sent back to the browser |

The browser never talks to the database or to Gemini directly — it only
ever calls your own backend, which is the only thing holding the API key
and DB access. That's the "only the model/backend can access the data"
security requirement from before, now enforced by the client/server split
too.

## Setup

**1. Install dependencies**
```bash
pip install -r requirements.txt
```

**2. Add your Gemini API key**

A `.env` file is already included in this folder. Open it in Notepad (or
any text editor) — it looks like this:
```
GEMINI_API_KEY=your-gemini-api-key-here
```
Replace `your-gemini-api-key-here` with your real key and save. Get a key
at https://aistudio.google.com/apikey.

Important on Windows: make sure Notepad saves it as `.env`, not `.env.txt`.
File Explorer hides extensions by default, so check with `dir /a` in this
folder — you should see a file literally named `.env`, not `.env.txt`.
This file is read automatically on startup, so you never need to run
`set`/`setx`/`export` again.

**3. Run the server**
```bash
python app.py
```

**4. Open the site**

Go to **http://localhost:8000** in your browser. You'll see a sidebar
listing your live tables (click one to auto-fill a question about it) and
a chat panel to ask anything.

## Refreshing data

Whenever your Magento export changes, replace the CSVs in `./data` and
restart `python app.py` — it rebuilds the database from scratch on every
startup, so it always reflects what's currently in that folder.

## Security

- Only `SELECT`/`WITH` queries are ever allowed to run (enforced in
  `sql_guard.py`); write/schema keywords (`INSERT`, `UPDATE`, `DELETE`,
  `DROP`, `ALTER`, `ATTACH`, `PRAGMA`, ...) are blocked outright.
- The database connection used to run generated queries is opened in
  **OS-level read-only mode**, as a second line of defense.
- Every query gets an automatic `LIMIT` if it doesn't already have one.
- The frontend only ever calls your backend's `/api/chat` and
  `/api/tables` — it has no direct access to the database, the CSVs, or
  your Gemini key.

## Deploying beyond your own machine

Right now this is meant to run locally (`localhost:8000`). To put it on a
real server so your team or WhatsApp/website visitors can reach it:

1. Host `app.py` on a server (Render, Railway, a VM, etc.) instead of your
   laptop.
2. Set `GEMINI_API_KEY` as an environment variable on that server (not a
   committed `.env` file).
3. Put it behind HTTPS and, if it's for internal use only, some form of
   login/access control — right now anyone who can reach the URL can ask
   it questions.
4. To wire in WhatsApp (per the original diagram), add a webhook route
   that receives WhatsApp messages (e.g. via Twilio or the WhatsApp
   Business API), calls `pipeline.answer_question()`, and sends the reply
   back through that channel.

## Files

- `app.py` — FastAPI web server (routes + startup DB build)
- `pipeline.py` — the 7-step orchestration logic
- `llm_client.py` — the two Gemini calls (question→SQL, rows→reply)
- `sql_guard.py` — read-only query validation/execution (security layer)
- `db_loader.py` — CSV → SQLite loader (rebuilds on every server start)
- `schema_utils.py` — live schema introspection for the LLM prompt
- `static/index.html` — the chat frontend
- `data/` — your Magento CSV exports
- `.env.example` — copy to `.env` and add your key

---

## Security fix (this version)

Earlier builds handed the LLM the full live schema and let it run
`SELECT *` against **every** raw table, including customer emails,
phone numbers, street addresses, and partial card numbers
(`sales_order_payment.cc_last4`). Any user could get that data back
just by phrasing a question the right way (e.g. "give me all customer
data").

This version adds a real access-control layer instead of trusting the
LLM's prompt:

1. **`db_loader.py`** loads every CSV into a hidden `<table>__raw`
   table, then creates a same-named **VIEW** exposing only an
   allowlisted (`PUBLIC_VIEWS`) set of columns. Emails are masked
   (`d***@example.com`); `telephone`, `street`, `postcode`, and
   `cc_last4` are dropped entirely. Any table *not* listed in
   `PUBLIC_VIEWS` gets no view at all -- new CSVs are denied by
   default until someone explicitly allowlists their columns.
2. **`schema_utils.py`** only ever reads `type='view'` from
   `sqlite_master` -- the LLM's prompt never contains the raw
   table/column names, so it can't ask for what it doesn't know
   exists.
3. **`sql_guard.py`** is the real enforcement point (defense-in-depth,
   doesn't just trust the schema): it rejects any query mentioning
   `__raw`, rejects bare `sqlite_master` access, and checks every
   `FROM`/`JOIN` target against a live allowlist of public views before
   running anything.
4. **`app.py`**'s `/api/tables` sidebar also only lists public views.
5. The "I couldn't answer that" reply now explains *why* (missing
   relationship/field in the dataset) and lists what's actually
   queryable, instead of repeating a generic line forever.

To extend this to a new CSV/table later: add it to `PUBLIC_VIEWS` in
`db_loader.py` with an explicit column list (or `None` for "no PII,
expose everything") -- it stays invisible to the chatbot until you do.

## Category questions ("how many products did women buy?") now work

Earlier builds had no link between `catalog_product_entity` and
`catalog_category_entity`, so any category-based question (including
ones using words like "Men"/"Women" that are literal category names in
this dataset, e.g. "how many products did women buy last month?") fell
through to `NO_QUERY_POSSIBLE` -- the exact "I couldn't find data
connecting that..." reply you may have seen.

This is fixed with a new link table:

- **`data/catalog_category_product.csv`** (`category_id, product_id`) --
  a real many-to-many mapping, loaded and exposed through
  `PUBLIC_VIEWS` like every other table.
- **`llm_client.py`**'s prompt now has explicit rules + worked examples
  for joining through it (`products in a category`, `revenue/units by
  category`), and a disambiguation rule: words that are both a category
  name and a demographic word ("Men", "Women") are always resolved as
  the **product category** -- since that's what this data can actually
  answer -- never as a customer attribute (there's still no per-customer
  gender/age field anywhere in the schema, so genuine demographic
  questions like "which customers identify as female?" or "average
  customer age" correctly still return `NO_QUERY_POSSIBLE`).
- `tools/generate_questions.py`'s question bank was updated to match:
  category-nameable questions moved from the `gap` category into `join`
  (they're answerable now), and `questions_1000.jsonl` /
  `questions_10000.jsonl` were regenerated.

If you load a real Magento export, either add your real
`catalog_category_product` table (Magento has one natively) or
regenerate a synthetic one the same way for a new product catalog --
without it, category questions go back to unanswerable, correctly.

## Groq now sees zero query results

Previously, `rows_to_reply()` sent every query's actual result rows to
Groq so it could phrase a friendly sentence -- meaning Groq received
real (already-masked) customer/order data on every question.

That call has been removed. `reply_formatter.py` now formats results
into a reply with plain Python (a one-line answer, a key/value list, or
a markdown table) -- no network call at all. The only remaining call to
Groq is `nl_to_sql()` in `llm_client.py`, and it only ever sends the
user's question text, conversation history, and the table/column
*schema* (structure, never actual row data) -- never a single query
result.

Net effect: Groq can no longer see your data, directly or indirectly --
only the shape of your questions and your database's structure.
